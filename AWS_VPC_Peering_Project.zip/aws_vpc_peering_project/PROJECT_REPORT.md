# PROJECT REPORT
## AWS VPC Peering and Secure Private EC2 Communication

### 1. Abstract
This project demonstrates secure communication between two isolated Amazon Virtual Private Clouds (VPCs) using AWS VPC Peering. Terraform is used to create the network infrastructure, route tables, security groups, and EC2 instances. A private web server in the second VPC is accessed from a controlled bastion host in the first VPC using its private IP address.

### 2. Problem Statement
Applications deployed in separate VPCs are isolated by default. A secure and simple method is required for resources in these VPCs to communicate without exposing application traffic to the public internet.

### 3. Objectives
- Create two separate AWS VPCs with non-overlapping CIDR blocks.
- Configure public and private subnets.
- Establish a VPC peering connection.
- Configure route tables for two-way private routing.
- Apply security-group rules to control traffic.
- Verify connectivity between EC2 instances using private IP addresses.
- Automate infrastructure deployment using Terraform.

### 4. Tools and Technologies
Amazon VPC, Amazon EC2, Internet Gateway, VPC Peering, Route Tables, Security Groups, Terraform, AWS CLI and GitHub.

### 5. System Design
VPC A uses CIDR `10.0.0.0/16`, with public subnet `10.0.1.0/24` and private subnet `10.0.2.0/24`. VPC B uses CIDR `10.200.0.0/16`, with private subnet `10.200.1.0/24`. A VPC peering connection links the two VPCs. Routes to the peer CIDR are added to the relevant route tables. A public bastion instance provides restricted administrative access, while private EC2 instances host a small HTTP test page.

### 6. Working
1. Terraform creates both VPCs and their subnets.
2. An Internet Gateway is attached to VPC A for the public subnet.
3. A peering connection is created between VPC A and VPC B.
4. Route tables are updated so each VPC knows how to reach the other VPC's CIDR.
5. Security groups permit only the required SSH and HTTP traffic.
6. EC2 instances start a basic HTTP server through user-data.
7. The user connects to the bastion and sends an HTTP request to the private EC2 instance in VPC B using its private IP.

### 7. Expected Result
The HTTP request from the bastion in VPC A to the private EC2 instance in VPC B returns a page containing **“VPC Peering is working!”**. This confirms that routing and security-group rules permit communication over the peering connection.

### 8. Advantages
- Private communication between separate VPCs.
- Application traffic does not need to traverse the public internet.
- Clear network isolation between environments.
- Infrastructure can be recreated consistently using Terraform.
- Security groups provide controlled access.

### 9. Limitations
VPC peering does not support transitive routing. The demo does not include high availability, centralized inspection, NAT, monitoring, or production-grade bastion hardening.

### 10. Conclusion
The project demonstrates how AWS VPC Peering connects two isolated VPC networks and enables controlled private communication between EC2 instances. Terraform makes the infrastructure repeatable and easier to manage.
