#!/bin/bash
set -eux
dnf install -y python3
mkdir -p /var/www/vpc-demo
cat > /var/www/vpc-demo/index.html <<'HTML'
<html>
  <head><title>AWS VPC Peering Demo</title></head>
  <body>
    <h1>VPC Peering is working!</h1>
    <p>This private EC2 web server is responding over the VPC network.</p>
  </body>
</html>
HTML
cat > /etc/systemd/system/vpc-demo.service <<'SERVICE'
[Unit]
Description=Simple VPC Peering Demo Web Server
After=network.target

[Service]
WorkingDirectory=/var/www/vpc-demo
ExecStart=/usr/bin/python3 -m http.server 80 --directory /var/www/vpc-demo
Restart=always
User=root

[Install]
WantedBy=multi-user.target
SERVICE
systemctl daemon-reload
systemctl enable --now vpc-demo.service
