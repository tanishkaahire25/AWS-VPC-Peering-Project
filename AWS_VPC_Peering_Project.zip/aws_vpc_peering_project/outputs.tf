output "bastion_public_ip" {
  description = "Public IP of the bastion EC2 instance"
  value       = aws_instance.bastion.public_ip
}

output "app_a_private_ip" {
  description = "Private IP of the EC2 instance in VPC A private subnet"
  value       = aws_instance.app_a.private_ip
}

output "app_b_private_ip" {
  description = "Private IP of the EC2 instance in VPC B private subnet"
  value       = aws_instance.app_b.private_ip
}

output "vpc_peering_connection_id" {
  description = "ID of the VPC peering connection"
  value       = aws_vpc_peering_connection.peer.id
}
