# AWS VPC Peering and Private EC2 Communication

## Project overview
This project creates two isolated AWS Virtual Private Clouds (VPCs) and connects them using VPC Peering. It demonstrates how private EC2 instances in separate VPCs can communicate using private IP addresses without sending application traffic over the public internet.

Infrastructure is provisioned using Terraform.

## Architecture

- **VPC A:** `10.0.0.0/16`
  - Public subnet: `10.0.1.0/24` — public bastion EC2 instance
  - Private subnet: `10.0.2.0/24` — private application EC2 instance
  - Internet Gateway and public route table
- **VPC B:** `10.200.0.0/16`
  - Private subnet: `10.200.1.0/24` — private application EC2 instance
- **VPC Peering:** Connects VPC A and VPC B.
- **Routing:** Both VPC A route tables and VPC B's private route table have routes for the peer VPC CIDR.
- **Security:** SSH to the bastion is restricted to the administrator's IP. The VPC B web server allows HTTP only from VPC A's CIDR.

> Note: The reference diagram uses `28.x.x.x` ranges, which are publicly routable address space, not RFC 1918 private ranges. This implementation uses non-overlapping RFC 1918 ranges (`10.0.0.0/16` and `10.200.0.0/16`) instead, which is the safer choice for a private VPC lab.

## Resources created

1. Two VPCs
2. Three subnets (two in VPC A and one in VPC B)
3. One Internet Gateway
4. Four route tables/route associations as defined in Terraform
5. One VPC peering connection
6. Three EC2 instances (one public bastion and two private application servers)
7. Three security groups

## Prerequisites

- An AWS account with permission to create VPC, EC2, security group, route table, and peering resources.
- Terraform 1.5 or later.
- AWS CLI configured with credentials for your own account.
- An existing EC2 key pair in the selected region.
- Your public IPv4 address in CIDR notation, normally `/32`.

## Deploy

1. Install Terraform and AWS CLI.
2. Configure AWS credentials locally using `aws configure` or an approved AWS credentials method.
3. In the AWS console, create or identify an EC2 key pair in `ap-south-1` (or change `aws_region`).
4. Copy `terraform.tfvars.example` to `terraform.tfvars`.
5. Set `key_pair_name` to your existing key pair name and `admin_cidr` to your public IP with `/32`.
6. Open a terminal in this project directory and run:

```bash
terraform init
terraform fmt
terraform validate
terraform plan
terraform apply
```

Review the plan before typing `yes`. Terraform will create billable AWS resources.

## Test connectivity

After apply completes, note the `bastion_public_ip` and `app_b_private_ip` outputs.

From your computer, connect to the bastion (replace the key path and IP):

```bash
ssh -i /path/to/your-key.pem ec2-user@BASTION_PUBLIC_IP
```

From the bastion, test the private web server in VPC B:

```bash
curl http://APP_B_PRIVATE_IP
```

Expected page content includes:

`VPC Peering is working!`

You can also test the VPC A private instance:

```bash
curl http://APP_A_PRIVATE_IP
```

The private instances do not receive public IP addresses. The bastion is used as the controlled entry point for this demonstration.

If the first request fails immediately after deployment, wait a few minutes for EC2 user-data setup to finish and retry.

## Important limitations and security notes

- This is a learning/demo architecture, not a production-ready design.
- SSH is restricted by `admin_cidr`; do not open SSH to `0.0.0.0/0`.
- The demo uses a public bastion. For production, prefer AWS Systems Manager Session Manager, hardened access controls, logging, and private endpoints.
- There is no NAT Gateway. The private EC2 instances do not have general outbound internet access. This keeps the demo simpler and avoids NAT Gateway charges.
- VPC peering is not transitive. A third VPC cannot automatically route through one of these VPCs.
- Check current AWS pricing and Free Tier eligibility for your account and region before deployment. EC2, public IPv4 addresses, storage, and data transfer may incur charges.

## Cleanup — avoid ongoing charges

When finished, run:

```bash
terraform destroy
```

Review the resources to be deleted and type `yes`. Confirm in the AWS console that the demo resources have been removed.

## Suggested GitHub repository description

**Terraform project that provisions two AWS VPCs, configures VPC Peering and route tables, and demonstrates private EC2-to-EC2 HTTP communication with security-group restrictions.**
