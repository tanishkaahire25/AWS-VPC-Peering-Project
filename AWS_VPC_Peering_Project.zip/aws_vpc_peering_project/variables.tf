variable "aws_region" {
  description = "AWS region for this project"
  type        = string
  default     = "ap-south-1"
}

variable "project_name" {
  description = "Prefix used for AWS resource names"
  type        = string
  default     = "vpc-peering-demo"
}

variable "instance_type" {
  description = "EC2 instance size. Check current AWS pricing before deployment."
  type        = string
  default     = "t3.micro"
}

variable "key_pair_name" {
  description = "Name of an existing EC2 key pair in the selected AWS region"
  type        = string
}

variable "admin_cidr" {
  description = "Your public IP in CIDR format, for example 203.0.113.10/32. Do not use 0.0.0.0/0."
  type        = string

  validation {
    condition     = can(cidrhost(var.admin_cidr, 0)) && tonumber(split("/", var.admin_cidr)[1]) >= 0 && tonumber(split("/", var.admin_cidr)[1]) <= 32
    error_message = "Enter a valid IPv4 CIDR, preferably your public IP followed by /32."
  }
}
